package mrz.dev.webxnet.activities;

import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import android.app.Activity;
import java.util.ArrayList;
import android.widget.LinearLayout;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ScrollView;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.Manifest;
import android.content.pm.PackageManager;
import mrz.dev.webxnet.R;

public class MainActivity extends Activity
{

	@Override
	public void onPointerCaptureChanged(boolean hasCapture)
	{
		// TODO: Implement this method
	}
	
	private boolean wLogs = false;

	private ArrayList<String> netdata = new ArrayList<>();

	private LinearLayout main_page;
	private LinearLayout toolbar;
	private LinearLayout splash_page;
	private LinearLayout logger_page;
	private WebView web;
	private ImageView back;
	private ImageView back2;
	private LinearLayout boundary;
	private LinearLayout search_bg;
	private ImageView ic_search;
	private ImageView inspect;
	private ImageView viewsource;
	private ImageView moresettings;
	private ImageView clear_logs;
	private TextView log_title;
	private EditText search;
	private ImageView erase_search;
	private ImageView ic_webxnet;
	private TextView tv_title;
	private TextView tv_script1;
	private TextView textview3;
	private TextView textview4;
	private LinearLayout bg_script23;
	private TextView tv_script4;
	private LinearLayout guide_bg;
	private TextView tv_subtitle;
	private TextView textview1;
	private TextView tv_script2;
	private TextView tv_label2;
	private TextView tv_script3;
	private TextView tv_label5;
	private ImageView imageview1;
	private TextView textview2;
	private ListView netlogs;
	private ScrollView js_scroll;
	private LinearLayout bg_scroll_logger;
	//private LinearLayout linecode_bg;
	private LinearLayout js_texts_bg;
	//private TextView linecode;
	private TextView loggr;
	private EditText jsinput;
    private ArrayAdapter<String> adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getActionBar().hide();
		
		main_page = (LinearLayout) findViewById(R.id.main_page);
		toolbar = (LinearLayout) findViewById(R.id.toolbar);
		splash_page = (LinearLayout) findViewById(R.id.splash_page);
		logger_page = (LinearLayout) findViewById(R.id.logger_page);
		web = (WebView) findViewById(R.id.web);
		web.getSettings().setJavaScriptEnabled(true);
		web.getSettings().setSupportZoom(true);
		back = (ImageView) findViewById(R.id.back);
		back2 = (ImageView) findViewById(R.id.back2);
		boundary = (LinearLayout) findViewById(R.id.boundary);
		search_bg = (LinearLayout) findViewById(R.id.search_bg);
		ic_search = (ImageView) findViewById(R.id.ic_search);
		inspect = (ImageView) findViewById(R.id.inspect);
		viewsource = (ImageView) findViewById(R.id.viewsource);
		moresettings = (ImageView) findViewById(R.id.moresettings);
		clear_logs = (ImageView) findViewById(R.id.clear_logs);
		log_title = (TextView) findViewById(R.id.log_title);
		search = (EditText) findViewById(R.id.search);
		erase_search = (ImageView) findViewById(R.id.erase_search);
		ic_webxnet = (ImageView) findViewById(R.id.ic_webxnet);
		tv_title = (TextView) findViewById(R.id.tv_title);
		tv_script1 = (TextView) findViewById(R.id.tv_script1);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		bg_script23 = (LinearLayout) findViewById(R.id.bg_script23);
		tv_script4 = (TextView) findViewById(R.id.tv_script4);
		guide_bg = (LinearLayout) findViewById(R.id.guide_bg);
		tv_subtitle = (TextView) findViewById(R.id.tv_subtitle);
		textview1 = (TextView) findViewById(R.id.textview1);
		tv_script2 = (TextView) findViewById(R.id.tv_script2);
		tv_label2 = (TextView) findViewById(R.id.tv_label2);
		tv_script3 = (TextView) findViewById(R.id.tv_script3);
		tv_label5 = (TextView) findViewById(R.id.tv_label5);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview2 = (TextView) findViewById(R.id.textview2);
		netlogs = (ListView) findViewById(R.id.netlogs);
		js_scroll = (ScrollView) findViewById(R.id.js_scroll);
		bg_scroll_logger = (LinearLayout) findViewById(R.id.bg_scroll_logger);
		//linecode_bg = (LinearLayout) findViewById(R.id.linecode_bg);
		js_texts_bg = (LinearLayout) findViewById(R.id.js_texts_bg);
		//linecode = (TextView) findViewById(R.id.linecode);
		loggr = (TextView) findViewById(R.id.loggr);
		jsinput = (EditText) findViewById(R.id.jsinput);

		back.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					search_bg.setVisibility(View.GONE);
					back.setVisibility(View.GONE);
					ic_search.setVisibility(View.VISIBLE);
					moresettings.setVisibility(View.VISIBLE);
					inspect.setVisibility(View.VISIBLE);
					viewsource.setVisibility(View.VISIBLE);
				}
			});

		back2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					/*true = xhr logs/console
					 *false = net logs/deeplinks
					 */
					back2.setVisibility(View.GONE);
					back.performClick();
					boundary.setVisibility(View.GONE);
					clear_logs.setVisibility(View.GONE);
					splash_page.setVisibility(View.VISIBLE);
					web.setVisibility(View.GONE);
					ic_search.setVisibility(View.VISIBLE);
					inspect.setVisibility(View.VISIBLE);
					viewsource.setVisibility(View.VISIBLE);
					moresettings.setVisibility(View.VISIBLE);
					logger_page.setVisibility(View.GONE);
					netlogs.setVisibility(View.GONE);
					js_scroll.setVisibility(View.GONE);
				}
			});

		ic_search.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					search_bg.setVisibility(View.VISIBLE);
					moresettings.setVisibility(View.GONE);
					ic_search.setVisibility(View.GONE);
					inspect.setVisibility(View.GONE);
					viewsource.setVisibility(View.GONE);
					back.setVisibility(View.VISIBLE);
					android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE); 
					imm.showSoftInput(search, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
				}
			});

		inspect.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					web.loadUrl("javascript:window.touchblock=!window.touchblock;setTimeout(function(){$$.blocktoggle(window.touchblock)}, 100);");
				}
			});

		clear_logs.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					AlertDialog.Builder dlg2=new AlertDialog.Builder(MainActivity.this);
					dlg2.setTitle("Clear Data logs");
					dlg2.setMessage("Are you sure you want to clear your saved logs?\nit cannot be recovered");
					dlg2.setPositiveButton("Yes", new DialogInterface.OnClickListener(){
							@Override
							public void onClick(DialogInterface p1, int p2) {

								loggr.setText("");

								netdata.clear();
								adapter.notifyDataSetChanged();
							}
						});
					dlg2.setNegativeButton("No", null);
					dlg2.show();
				}
			});

		search.addTextChangedListener(new TextWatcher() {
				@Override
				public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
					final String _charSeq = _param1.toString();
					if (_charSeq.equals("")) {
						erase_search.setVisibility(View.GONE);
					}
					else {
						erase_search.setVisibility(View.VISIBLE);
						if (_charSeq.equals("webx://netlogs")) {
							showNetLogs();
						}
						else {
							if (_charSeq.equals("webx://xhrlogs")) {
								showXhrLogs();
							}
							else {

							}
						}
					}
				}

				@Override
				public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {

				}

				@Override
				public void afterTextChanged(Editable _param1) {

				}
			});

		erase_search.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					search.setText("");
				}
			});

		search_bg.setVisibility(View.GONE);
		back.setVisibility(View.GONE);
		erase_search.setVisibility(View.GONE);
		setRadiusToView(search_bg, 50, "#263238");
		setRadiusToView(ic_search, 360, "#263238");
		setRadiusToView(moresettings, 360, "#263238");
		back2.performClick();
		/*
		 *Perform search event
		 */
		jsinput.setOnKeyListener(new View.OnKeyListener() {
				public boolean onKey(View v, int keyCode, KeyEvent event) {
					if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
						(keyCode == KeyEvent.KEYCODE_ENTER)) {
						String js=jsinput.getText().toString().replaceAll(";$","");
						web.loadUrl(String.format("javascript:%s%s%s",js.startsWith("console.")?"":"console.log(", js, js.startsWith("console.")?"":");"));

						jsinput.setText("");
						return true;
					}
					return false;
				}
			});
		webinit();
		search.setOnKeyListener(new OnKeyListener() { public boolean onKey(View v, int keyCode, KeyEvent event) {
					if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) { // Perform action on search
						if (search.getText().toString().startsWith("webx://")) {
							if (search.getText().toString().equals("webx://netlogs")) {
								showNetLogs();
							}
							else {
								if (search.getText().toString().equals("webx://xhrlogs")) {
									showXhrLogs();
								}
								else {

								}
							}
						}
						else {
							String urlinput = search.getText().toString();
							if(!urlinput.trim().matches("https?://.*")){
								urlinput="http://"+urlinput.trim();
							}
							if(android.util.Patterns.WEB_URL.matcher(urlinput).matches()){
								web.loadUrl(urlinput);

								splash_page.setVisibility(View.GONE);
								hideAll();
								web.setVisibility(View.VISIBLE);
							}else /* web.loadUrl(urlinput); splash_page.setVisibility(View.GONE); hideAll(); web.setVisibility(View.VISIBLE);*/ Toast.makeText(MainActivity.this, "Invalid URL or web address but loaded!",0).show();
						}
						return true; } return false; } });

		netlogs.setAdapter(adapter=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, netdata));
	
	}
	private void showSourceDialog(final String s, final String r){
		View v=getLayoutInflater().inflate(R.layout.source, null);
		final EditText ed=(EditText)v.findViewById(R.id.sourceEditText1);
		final ImageView close=(ImageView)v.findViewById(R.id.closeBtn);
		final TextView scType=(TextView)v.findViewById(R.id.neutralBtn);
		final TextView save=(TextView)v.findViewById(R.id.positiveBtn);
		final TextView titleDlg=(TextView)v.findViewById(R.id.titleTv);
		
		ed.setText(r);
		ed.setTag(false);
		final AlertDialog dl=new AlertDialog.Builder(MainActivity.this).create();
		//dl.setTitle("Source Code");
		dl.requestWindowFeature(Window.FEATURE_NO_TITLE);
		dl.setView(v);
		close.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				dl.dismiss();
			}
		});
		save.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v){
				web.loadUrl("javascript:window.ganti"+((boolean)ed.getTag()?"behind":"")+"('"+ed.getText().toString()+"');");
			}
		} );
		
		
		 
		
		scType.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View p1) {
					ed.setText((boolean)ed.getTag()?r:s);
					scType.setText((boolean)ed.getTag()?"Behind":"Advanced");
					ed.setTag(!(boolean)ed.getTag());
				}
			});
			dl.show();
	}

	class MyJavaScriptInterface {
		@JavascriptInterface
		@SuppressWarnings("unused")
		public void log(final String content, final String url, final String arg) {
			web.post(new Runnable(){
					@Override
					public void run() {
						loggr.append(String.format("REQ: %s\nARG: %s\nRESP: %s\n--------------------\n",url,arg, content));
					}
				});
		}
		@JavascriptInterface
		@SuppressWarnings("unused")
		public void print(final String contentparent, final String content) {
			web.post(new Runnable(){
					@Override
					public void run() {
						showSourceDialog(contentparent, content);
					}
				});
		}
		@JavascriptInterface
		@SuppressWarnings("unused")
		public void blocktoggle(final String val){
			web.post(new Runnable(){
					@Override
					public void run() {
						Toast.makeText(MainActivity.this, val.matches("(1|true)")?"Touch Inspector is Activated":"Touch Inspector is Deactivated",1).show();
					}
				});

		}
	}
	private void setClipboard(String text) {
		if(android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.HONEYCOMB) {
			android.text.ClipboardManager clipboard = (android.text.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
			clipboard.setText(text);
		} else {
			android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
			android.content.ClipData clip = android.content.ClipData.newPlainText("Copied Text", text);
			clipboard.setPrimaryClip(clip);
		}
	}
	private void webinit() {
		// atur webview agar support js
		web.getSettings().setJavaScriptEnabled(true);
		// agar bisa di inspect melalui chrome di pc
		web.setWebContentsDebuggingEnabled(true);
		// register fungsi javascript
		web.addJavascriptInterface(new MyJavaScriptInterface(), "$$");
		// navigation callback
		web.setWebViewClient(new WebViewClient() {
				@Override
				public void onPageStarted(WebView view, String url, Bitmap favicon) {
					//setTitle("Loading...");
					super.onPageStarted(view, url, favicon);
				}
				@Override
				public WebResourceResponse shouldInterceptRequest(WebView view, final String url) {
					// capture semua request ke listview
					view.post(new Runnable(){
							@Override
							public void run() {
								netdata.add(url);
								adapter.notifyDataSetChanged();
							}
						});
					return super.shouldInterceptRequest(view, url);
				}
				// saat halaman selesai di load, inject js
				@Override
				public void onPageFinished(WebView view, String url) {
					//setTitle(view.getTitle());
					view.loadUrl("javascript:function injek3(){window.hasdir=1;window.dir=function(n){var r=[];for(var t in n)'function'==typeof n[t]&&r.push(t);return r}};if(window.hasdir!=1){injek3();}");

					view.loadUrl("javascript:function injek2(){window.touchblock=0,window.dummy1=1,document.addEventListener('click',function(n){if(1==window.touchblock){n.preventDefault();n.stopPropagation();var t=document.elementFromPoint(n.clientX,n.clientY);window.ganti=function(n){t.outerHTML=n},window.gantiparent=function(n){t.parentElement.outerHTML=n},$$.print(t.parentElement.outerHTML, t.outerHTML)}},!0)}1!=window.dummy1&&injek2();");

					view.loadUrl("javascript:function injek(){window.hasovrde=1;var e=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(ee,nn,aa){this.addEventListener('load',function(){$$.log(this.responseText, nn, JSON.stringify(arguments))}),e.apply(this,arguments)}};if(window.hasovrde!=1){injek();}");

					super.onPageFinished(view, url);
				}
			});
		web.setWebChromeClient(new WebChromeClient(){
				@Override
				public boolean onConsoleMessage(android.webkit.ConsoleMessage consoleMessage) {
					loggr.append(consoleMessage.message()+"\n--------------------\n");
					return false;
				}
			});
	}
	/*
	 function inject3() {
	 window.hasdir = 1;
	 window.dir = function(n) {
	 var r = [];
	 for (var t in n) 'function' == typeof n[t] && r.push(t);
	 return r
	 }
	 };
	 if (window.hasdir != 1) {
	 injek3();
	 }

	 function inject2() {
	 window.touchblock = 0, window.dummy1 = 1, document.addEventListener('click', function(n) {
	 if (1 == window.touchblock) {
	 n.preventDefault();
	 n.stopPropagation();
	 var t = document.elementFromPoint(n.clientX, n.clientY);
	 window.ganti = function(n) {
	 t.outerHTML = n
	 }, window.gantiparent = function(n) {
	 t.parentElement.outerHTML = n
	 }, $$.print(t.parentElement.outerHTML, t.outerHTML)
	 }
	 }, !0)
	 }
	 1 != window.dummy1 && injek2();

	 function inject() {
	 window.hasovrde = 1;
	 var e = XMLHttpRequest.prototype.open;
	 XMLHttpRequest.prototype.open = function(ee, nn, aa) {
	 this.addEventListener('load', function() {
	 $$.log(this.responseText, nn, JSON.stringify(arguments))
	 }), e.apply(this, arguments)
	 }
	 };
	 if (window.hasovrde != 1) {
	 injek();
	 }
	 */

	
	//}

	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);

		switch (_requestCode) {

			default:
				break;
		}
	}

	@Override
	public void onBackPressed() {
		if (web.canGoBack()) {
			web.goBack();
		}
		else {
			finish();
		}
	}
	private void setRadiusToView (final View _view, final double _radius, final String _color) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); gd.setColor(Color.parseColor(_color)); gd.setCornerRadius((int)_radius); _view.setBackground(gd);
	}


	private void showXhrLogs () {
		wLogs = true;
		/*true = xhr logs/console
		 *false = net logs/deeplinks
		 */
		js_scroll.post(new Runnable() { public void run() { js_scroll.fullScroll(js_scroll.FOCUS_DOWN); } });
		log_title.setText("Console");
		back2.setVisibility(View.VISIBLE);
		back.setVisibility(View.GONE);
		boundary.setVisibility(View.VISIBLE);
		search_bg.setVisibility(View.GONE);
		clear_logs.setVisibility(View.VISIBLE);
		splash_page.setVisibility(View.GONE);
		web.setVisibility(View.GONE);
		ic_search.setVisibility(View.GONE);
		inspect.setVisibility(View.GONE);
		viewsource.setVisibility(View.GONE);
		moresettings.setVisibility(View.GONE);
		logger_page.setVisibility(View.VISIBLE);
		netlogs.setVisibility(View.GONE);
		js_scroll.setVisibility(View.VISIBLE);
	}


	private void showNetLogs () {
		wLogs = false;
		/*true = xhr logs/console
		 *false = net logs/deeplinks
		 */
		log_title.setText("Deep-links");
		back2.setVisibility(View.VISIBLE);
		back.setVisibility(View.GONE);
		boundary.setVisibility(View.VISIBLE);
		search_bg.setVisibility(View.GONE);
		clear_logs.setVisibility(View.VISIBLE);
		splash_page.setVisibility(View.GONE);
		web.setVisibility(View.GONE);
		ic_search.setVisibility(View.GONE);
		inspect.setVisibility(View.GONE);
		viewsource.setVisibility(View.GONE);
		moresettings.setVisibility(View.GONE);
		logger_page.setVisibility(View.VISIBLE);
		netlogs.setVisibility(View.VISIBLE);
		js_scroll.setVisibility(View.GONE);
		netlogs.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener(){
				@Override
				public boolean onItemLongClick(AdapterView<?> p1, View p2, int p3, long p4) {
					setClipboard((String)p1.getItemAtPosition(p3));
					Toast.makeText(MainActivity.this, "Copied to Clipboard",0).show();
					p1.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
					return true;
				}
			});
		// load url saat listview log di klik
		netlogs.setOnItemClickListener(new AdapterView.OnItemClickListener(){
				@Override
				public void onItemClick(AdapterView<?> p1, View p2, int p3, long p4) {
					web.loadUrl((String)p1.getItemAtPosition(p3));
					hideAll();
					web.setVisibility(View.VISIBLE);
					splash_page.setVisibility(View.GONE);
				}
			});
	}


	private void _hideLogs () {

	}


	private void hideAll () {
		back2.setVisibility(View.GONE);
		back.setVisibility(View.GONE);
		boundary.setVisibility(View.GONE);
		search_bg.setVisibility(View.GONE);
		clear_logs.setVisibility(View.GONE);
		splash_page.setVisibility(View.GONE);
		ic_search.setVisibility(View.VISIBLE);
		inspect.setVisibility(View.VISIBLE);
		viewsource.setVisibility(View.VISIBLE);
		moresettings.setVisibility(View.VISIBLE);
		logger_page.setVisibility(View.GONE);
		netlogs.setVisibility(View.GONE);
		js_scroll.setVisibility(View.GONE);
	}
	
	
}
